package com.student.notice.management.system.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "contents")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Content {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;

    @Column(columnDefinition = "TEXT")
    private String body;

    // Creator info
    private Long createdByUserId;
    private String createdByName;
    private String createdByRole;

    private String roleVisibility;
    private String department;
    private String gradeLevel;
    private String classification;
    @Column(nullable = false)
    private String status = "DRAFT"; // DRAFT, PENDING_APPROVAL, PUBLISHED, ARCHIVED
    private int version = 1;

    private LocalDateTime scheduledStart;
    private LocalDateTime scheduledEnd;
    private String recurrence; // NONE, DAILY, WEEKLY, MONTHLY

    private boolean requiresApproval;
    private boolean approved;

    @ElementCollection
    @Builder.Default
    private List<String> attachments = new ArrayList<>();

    @ElementCollection
    @Builder.Default
    private List<Long> specificUserIds = new ArrayList<>();

    private String urgencyLevel;
    private boolean featured;

    private int readCount;
    private int deliveryAttempts;
    private int failedDeliveries;

    private boolean emailSent;
    private boolean smsSent;
    private boolean pushSent;
    private boolean inAppNotificationSent;

    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
    private LocalDateTime archivedAt;

    @ElementCollection
    @Builder.Default
    private List<String> categories = new ArrayList<>();

    @ElementCollection
    @Builder.Default
    private List<String> tags = new ArrayList<>();

    @ElementCollection
    @Builder.Default
    private List<Long> relatedContentIds = new ArrayList<>();

    @ElementCollection
    @Builder.Default
    private List<Long> bookmarkedByUserIds = new ArrayList<>();

    private int viewScore;
    private int interactionScore;

    private String approvalStage;

    @ElementCollection
    @Builder.Default
    private List<String> approvalHistory = new ArrayList<>();
}
