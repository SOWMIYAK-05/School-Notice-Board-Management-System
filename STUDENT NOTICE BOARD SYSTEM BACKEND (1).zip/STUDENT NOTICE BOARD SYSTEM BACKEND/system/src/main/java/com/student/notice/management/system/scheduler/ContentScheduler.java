package com.student.notice.management.system.scheduler;

import com.student.notice.management.system.service.ContentService;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ContentScheduler {

    private final ContentService contentService;

    // Run every hour to archive expired content
    @Scheduled(fixedRate = 60 * 60 * 1000)
    public void archiveExpiredContent() {
        contentService.archiveExpiredContent();
    }
}
