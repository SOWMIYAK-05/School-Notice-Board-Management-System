package com.student.notice.management.system.dto;

import lombok.Data;

@Data
public class CommentRequest {
    private String text;
}
