package com.student.notice.management.system.controller;

import com.student.notice.management.system.dto.AuthResponse;
import com.student.notice.management.system.dto.RegisterRequest;
import com.student.notice.management.system.dto.UserResponseDTO;
import com.student.notice.management.system.model.User;
import com.student.notice.management.system.repository.UserRepository;
import com.student.notice.management.system.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final AuthService authService;  // ✅ Inject AuthService

    // 🔹 Approve a user
    @PutMapping("/approve/{userId}")
    public ResponseEntity<String> approveUser(@PathVariable Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);

        if (optionalUser.isEmpty()) {
            return ResponseEntity.badRequest().body("User not found");
        }

        User user = optionalUser.get();
        if (user.isAdminApproved()) {
            return ResponseEntity.ok("User already approved");
        }

        user.setAdminApproved(true);
        userRepository.save(user);

        return ResponseEntity.ok("User approved successfully");
    }

    // 🔹 View all users with pagination & sorting
    @GetMapping("/users")
    public ResponseEntity<Page<UserResponseDTO>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,        // page number (0-based)
            @RequestParam(defaultValue = "10") int size,       // page size
            @RequestParam(defaultValue = "id") String sortBy,  // sort field
            @RequestParam(defaultValue = "asc") String order   // sort direction
    ) {
        Sort sort = order.equalsIgnoreCase("desc") ?
                Sort.by(sortBy).descending() :
                Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        Page<UserResponseDTO> users = userRepository.findAll(pageable)
                .map(user -> new UserResponseDTO(
                        user.getId(),
                        user.getFullName(),
                        user.getInstitutionalId(),
                        user.getEmail(),
                        user.getRole(),
                        user.getDepartment(),
                        user.getGradeLevel(),
                        user.getEmergencyContact(),
                        user.isAdminApproved(),
                        user.getAssignedClass(),
                        user.getChildId()
                ));

        return ResponseEntity.ok(users);
    }

    // 🔹 Delete a user
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable Long userId) {
        if (!userRepository.existsById(userId)) {
            return ResponseEntity.badRequest().body("User not found");
        }

        userRepository.deleteById(userId);
        return ResponseEntity.ok("User deleted successfully");
    }

    // 🔹 Admin can create users of any role
    @PostMapping("/create-user")
    public ResponseEntity<AuthResponse> createUserByAdmin(@RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request, true));
    }
}
