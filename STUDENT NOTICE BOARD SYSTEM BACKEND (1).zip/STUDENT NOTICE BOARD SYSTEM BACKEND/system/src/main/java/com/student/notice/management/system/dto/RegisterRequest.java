package com.student.notice.management.system.dto;

import lombok.Data;

@Data
public class RegisterRequest {
    private String fullName;
    private String institutionalId;
    private String email;
    private String password;
    private String role;          // now String instead of Enum
    private String department;
    private String gradeLevel;
    private String emergencyContact;
    private Long childId;         // student account this parent belongs to
    private String assignedClass; // for teachers
}
