package com.student.notice.management.system.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Full name is required")
    private String fullName;

    @NotBlank(message = "Institutional ID is required")
    private String institutionalId;

    @Email
    @NotBlank(message = "Email is required")
    @Column(unique = true)
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    // Role stored as plain string (e.g., "STUDENT", "TEACHER", "ADMIN")
    private String role;

    private String department;
    private String gradeLevel;   // only for students
    private String emergencyContact;

    private boolean emailVerified = false;
    private boolean adminApproved = false;

    private String notificationPreferences;
    private String communicationPreferences;

    private String assignedClass;   // For teachers
    private Long childId;         // For parents (optional for mapping)

}
