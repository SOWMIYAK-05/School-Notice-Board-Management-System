package com.student.notice.management.system.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthResponse {
    private String token;   // JWT token (only for login)
    private String role;    // User role (only for login)
    private String message; // Info message (for both register & login)
}
