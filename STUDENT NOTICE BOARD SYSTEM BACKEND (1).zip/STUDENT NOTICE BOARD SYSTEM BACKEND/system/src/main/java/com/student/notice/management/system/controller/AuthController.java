package com.student.notice.management.system.controller;

import com.student.notice.management.system.dto.AuthResponse;
import com.student.notice.management.system.dto.LoginRequest;
import com.student.notice.management.system.dto.RegisterRequest;
import com.student.notice.management.system.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    // PUBLIC STUDENT REGISTRATION
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registerStudent(@RequestBody RegisterRequest request) {
        request.setRole("STUDENT"); // Force role as STUDENT for public registration
        return ResponseEntity.ok(authService.register(request, false));
    }

    // COMMON LOGIN
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
