package com.student.notice.management.system.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long contentId;
    private Long userId;

    private String channel; // EMAIL, SMS, PUSH, IN_APP
    private boolean delivered;

    @Column(name = "`read`")
    private boolean read;

    private String message; // 🆕 Notification message

    private LocalDateTime deliveredAt;
    private LocalDateTime readAt;
}
