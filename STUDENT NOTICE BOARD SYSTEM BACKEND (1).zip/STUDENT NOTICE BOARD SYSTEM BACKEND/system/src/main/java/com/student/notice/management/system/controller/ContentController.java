    package com.student.notice.management.system.controller;

    import com.student.notice.management.system.model.Content;
    import com.student.notice.management.system.security.JwtUtil;
    import com.student.notice.management.system.service.ContentService;
    import lombok.RequiredArgsConstructor;
    import org.springframework.data.domain.Page;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.*;
    import org.springframework.web.multipart.MultipartFile;
    import com.student.notice.management.system.dto.ContentRequest;

    import java.io.IOException;
    import java.time.LocalDateTime;
    import java.util.List;
    import java.util.Map;
    import java.util.Arrays;
    import java.util.UUID;

    @RestController
    @RequestMapping("/api/content")
    @RequiredArgsConstructor
    public class ContentController {

        private final ContentService contentService;
        private final JwtUtil jwtUtil;

        @GetMapping("/visible")
        public ResponseEntity<List<Content>> getVisibleContent(@RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            Long userId = jwtUtil.extractUserId(jwt);
            return ResponseEntity.ok(contentService.getVisibleContent(userId));
        }

        @DeleteMapping("/del/{id}")
        public ResponseEntity<String> deleteContent(
                @PathVariable Long id,
                @RequestHeader("Authorization") String token) {

            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);

            contentService.deleteContent(id, role);
            return ResponseEntity.ok("✅ Content deleted successfully");
        }


        // 📝 MODIFIED ENDPOINT to correctly map to the new workflow
        @PostMapping("/create")
        public ResponseEntity<Content> createContent(
                @ModelAttribute ContentRequest contentRequest,
                @RequestPart(value = "files", required = false) List<MultipartFile> files,
                @RequestParam(defaultValue = "false") boolean draft,
                @RequestHeader("Authorization") String token) throws IOException {

            String jwt = token.substring(7);
            Long userId = jwtUtil.extractUserId(jwt);
            String role = jwtUtil.extractRole(jwt);
            String fullName = jwtUtil.extractUsername(jwt); // 🔹 assuming JwtUtil can extract fullName

            // Map DTO to entity
            Content content = Content.builder()
                    .title(contentRequest.getTitle())
                    .body(contentRequest.getBody())
                    .roleVisibility(contentRequest.getRoleVisibility())
                    .department(contentRequest.getDepartment())
                    .gradeLevel(contentRequest.getGradeLevel())
                    .classification(contentRequest.getClassification())
                    .urgencyLevel(contentRequest.getUrgencyLevel())
                    .featured(contentRequest.isFeatured())
                    .scheduledStart(contentRequest.getScheduledStart())
                    .scheduledEnd(contentRequest.getScheduledEnd())
                    .recurrence(contentRequest.getRecurrence())
                    .categories(Arrays.asList(contentRequest.getCategories().split(",")))
                    .tags(Arrays.asList(contentRequest.getTags().split(",")))
                    // 🔹 Creator info
                    .createdByUserId(userId)
                    .createdByName(fullName)
                    .createdByRole(role)
                    .build();

            return ResponseEntity.ok(contentService.createOrUpdateContent(content, role, draft, files));
        }


        @PutMapping("/approve/{id}")
        public ResponseEntity<Content> approveContent(@PathVariable Long id, @RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);
            return ResponseEntity.ok(contentService.approveContent(id, role));
        }

        @PostMapping("/bulk-create")
        public ResponseEntity<List<Content>> bulkCreate(@RequestBody List<Content> contents, @RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);
            return ResponseEntity.ok(contents.stream()
                    .map(c -> {
                        try { return contentService.createOrUpdateContent(c, role, false, null); }
                        catch (IOException e) { throw new RuntimeException(e); }
                    }).toList());
        }

        // 🔹 Advanced search
        @GetMapping("/search")
        public ResponseEntity<List<Content>> searchContent(
                @RequestParam(required = false) String keyword,
                @RequestParam(required = false) String category,
                @RequestParam(required = false) String tag,
                @RequestParam(required = false) String start,
                @RequestParam(required = false) String end,
                @RequestParam(required = false) String status
        ) {
            LocalDateTime startDate = start != null ? LocalDateTime.parse(start) : null;
            LocalDateTime endDate = end != null ? LocalDateTime.parse(end) : null;
            return ResponseEntity.ok(contentService.searchContent(keyword, category, tag, startDate, endDate, status));
        }

        @PostMapping("/bookmark/{contentId}")
        public ResponseEntity<Content> bookmarkContent(
                @PathVariable Long contentId,
                @RequestHeader("Authorization") String token) {

            String jwt = token.substring(7);
            Long userId = jwtUtil.extractUserId(jwt);
            return ResponseEntity.ok(contentService.bookmarkContent(contentId, userId));
        }

        @GetMapping("/related/{contentId}")
        public ResponseEntity<List<Content>> getRelatedContent(@PathVariable Long contentId) {
            return ResponseEntity.ok(contentService.getRelatedContent(contentId));
        }

        // 🆕 NEW ENDPOINT: Get all draft content
        @GetMapping("/drafts")
        public ResponseEntity<List<Content>> getDraftContents(@RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);
            return ResponseEntity.ok(contentService.getDraftContents(role));
        }

        // 🔹 NEW ENDPOINT: Publish draft content
        @PutMapping("/publish/{id}")
        public ResponseEntity<Content> publishContent(
                @PathVariable Long id,
                @RequestHeader("Authorization") String token) {

            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);

            return ResponseEntity.ok(contentService.publishContent(id, role));
        }


        // 🆕 NEW ENDPOINT: Get all published content
        @GetMapping("/published")
        public ResponseEntity<List<Content>> getPublishedContents(@RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);
            return ResponseEntity.ok(contentService.getPublishedContents(role));
        }

        // 🔹 Analytics & Reporting endpoints
        @GetMapping("/analytics")
        public ResponseEntity<Map<String, Object>> getContentAnalytics(
                @RequestParam(required = false) String status,
                @RequestParam(defaultValue = "0") int page,
                @RequestParam(defaultValue = "10") int size,
                @RequestParam(defaultValue = "createdAt") String sortBy,
                @RequestParam(defaultValue = "desc") String sortDir) {

            Page<Content> contentPage = contentService.getContentAnalytics(status, page, size, sortBy, sortDir);
            Map<String, Object> response = Map.of(
                    "contents", contentPage.getContent(),
                    "currentPage", contentPage.getNumber(),
                    "totalItems", contentPage.getTotalElements(),
                    "totalPages", contentPage.getTotalPages()
            );
            return ResponseEntity.ok(response);
        }
        // 🆕 NEW ENDPOINT: Get all content pending approval
        @GetMapping("/pending-approvals")
        public ResponseEntity<List<Content>> getPendingApprovals(@RequestHeader("Authorization") String token) {
            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);
            Long userId = jwtUtil.extractUserId(jwt); // 👈 make sure JwtUtil has this

            return ResponseEntity.ok(contentService.getPendingApprovalContents(role, userId));
        }


        @GetMapping("/metrics/{contentId}")
        public ResponseEntity<Map<String, Object>> getContentMetrics(@PathVariable Long contentId) {
            Content content = contentService.getVisibleContent(contentId).stream().findFirst()
                    .orElseThrow(() -> new RuntimeException("Content not found"));
            return ResponseEntity.ok(contentService.calculateEngagementMetrics(content));
        }

        // View a particular pending approval content
        @GetMapping("/pending-approvals/{id}")
        public ResponseEntity<Content> viewPendingApprovalContent(
                @PathVariable Long id,
                @RequestHeader("Authorization") String token) {

            String jwt = token.substring(7);
            String role = jwtUtil.extractRole(jwt);

            Content content = contentService.viewPendingApprovalContent(id, role);
            return ResponseEntity.ok(content);
        }

    }