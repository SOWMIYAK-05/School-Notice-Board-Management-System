package com.student.notice.management.system.service;

import com.student.notice.management.system.dto.AuthResponse;
import com.student.notice.management.system.dto.LoginRequest;
import com.student.notice.management.system.dto.RegisterRequest;
import com.student.notice.management.system.model.User;
import com.student.notice.management.system.repository.UserRepository;
import com.student.notice.management.system.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;

    /**
     * @param isAdminCreation true if admin is creating the user
     */
    public AuthResponse register(RegisterRequest request, boolean isAdminCreation) {
        if (userRepository.existsByEmail(request.getEmail())) {
            return new AuthResponse(null, null, "Email already registered");
        }

        // Public registration can only create STUDENT
        if (!isAdminCreation && !"STUDENT".equalsIgnoreCase(request.getRole())) {
            return new AuthResponse(null, null, "Only students can register publicly");
        }

        User.UserBuilder userBuilder = User.builder()
                .fullName(request.getFullName())
                .institutionalId(request.getInstitutionalId())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole().toUpperCase())
                .department(request.getDepartment())
                .gradeLevel(request.getGradeLevel())
                .emergencyContact(request.getEmergencyContact())
                .emailVerified(false)
                .adminApproved(isAdminCreation); // auto-approved if admin creates user

        // Parent-specific
        if ("PARENT".equalsIgnoreCase(request.getRole()) && request.getChildId() != null) {
            userBuilder.childId(request.getChildId());
        }

        // Teacher-specific
        if ("TEACHER".equalsIgnoreCase(request.getRole())) {
            userBuilder.assignedClass(request.getAssignedClass());
        }

        User user = userBuilder.build();
        userRepository.save(user);

        return new AuthResponse(null, user.getRole(), isAdminCreation
                ? "User created successfully by admin"
                : "Registration successful. Awaiting admin approval.");
    }

    // LOGIN
    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!user.isAdminApproved()) {
            return new AuthResponse(null, null, "Account not approved by admin yet.");
        }

        String token = jwtUtil.generateToken(user.getEmail(), user.getRole(), user.getId());
        return new AuthResponse(token, user.getRole(), "Login successful");
    }
}
