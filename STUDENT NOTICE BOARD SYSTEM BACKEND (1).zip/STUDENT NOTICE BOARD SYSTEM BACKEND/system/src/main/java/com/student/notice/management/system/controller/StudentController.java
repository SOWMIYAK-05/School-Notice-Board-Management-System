// src/main/java/com/student/notice/management/system/controller/StudentPageController.java
package com.student.notice.management.system.controller;

import com.student.notice.management.system.model.Content;
import com.student.notice.management.system.model.Comment;
import com.student.notice.management.system.model.Notification;
import com.student.notice.management.system.repository.ContentRepository;
import com.student.notice.management.system.security.JwtUtil;
import com.student.notice.management.system.service.ContentService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/student/page")
@RequiredArgsConstructor
public class StudentController { // Corrected class name

    private final ContentService contentService;
    private final JwtUtil jwtUtil;
    private final ContentRepository contentRepository;
    private final S3Client s3Client; // Inject S3Client

    // 🔹 1. Get all published content
    @GetMapping("/contents")
    public ResponseEntity<List<Content>> getAllPublishedContent(@RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        String role = jwtUtil.extractRole(jwt);
        return ResponseEntity.ok(contentService.getPublishedContents(role));
    }

    // 🔹 2. Get details of a content
    // 🔹 2. Get details of a content + increment view score
    @GetMapping("/content/{id}")
    public ResponseEntity<Content> getContentDetails(@PathVariable Long id) {
        Content content = contentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        // ✅ Increment view score whenever student views
        contentService.incrementViewScore(id);

        return ResponseEntity.ok(content);
    }


    // 🔹 3. Add comment
    @PostMapping("/content/{id}/comment")
    public ResponseEntity<Comment> addComment(
            @PathVariable Long id,
            @RequestParam String text,
            @RequestHeader("Authorization") String token) {

        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);
        String userName = jwtUtil.extractUsername(jwt);

        Comment comment = contentService.addComment(id, userId, userName, text);

        // ✅ Increase interaction score for comment
        contentService.updateInteractionScore(id, "comment");

        return ResponseEntity.ok(comment);
    }


    // 🔹 4. Get comments for content
    @GetMapping("/content/{id}/comments")
    public ResponseEntity<List<Comment>> getComments(@PathVariable Long id) {
        return ResponseEntity.ok(contentService.getComments(id));
    }

    // 🔹 5. Bookmark content
    @PostMapping("/content/{id}/bookmark")
    public ResponseEntity<Content> bookmarkContent(
            @PathVariable Long id,
            @RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);

        Content content = contentService.bookmarkContent(id, userId);

        // ✅ Increase interaction score for bookmark
        contentService.updateInteractionScore(id, "bookmark");

        return ResponseEntity.ok(content);
    }


    // 🔹 6. Remove bookmark
    @DeleteMapping("/content/{id}/bookmark")
    public ResponseEntity<Content> removeBookmark(
            @PathVariable Long id,
            @RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);

        Content content = contentService.removeBookmark(id, userId);

        // ✅ Decrease interaction score
        contentService.updateInteractionScore(id, "remove_bookmark");

        return ResponseEntity.ok(content);
    }


    // 🔹 7. View notifications
    @GetMapping("/notifications")
    public ResponseEntity<List<Notification>> getNotifications(@RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);
        return ResponseEntity.ok(contentService.getNotifications(userId));
    }

    // 🔹 8. Mark notification as read
    @PutMapping("/notifications/{id}/read")
    public ResponseEntity<Notification> markNotificationAsRead(
            @PathVariable Long id,
            @RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);
        return ResponseEntity.ok(contentService.markNotificationAsRead(id, userId));
    }

    // 🔹 9. Check if content is bookmarked
    @GetMapping("/content/{id}/bookmark/status")
    public ResponseEntity<Boolean> isBookmarked(
            @PathVariable Long id,
            @RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        Long userId = jwtUtil.extractUserId(jwt);

        Content content = contentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        boolean isBookmarked = content.getBookmarkedByUserIds().contains(userId);
        return ResponseEntity.ok(isBookmarked);
    }

    // 🔹 10. Get image from AWS S3
    @GetMapping("/files/{fileName:.+}")
    public ResponseEntity<Resource> getFileFromS3(@PathVariable String fileName) {
        try {
            // ✅ Refactored to get file from S3 instead of local disk
            GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                    .bucket("your-s3-bucket-name") // Replace with your actual bucket name
                    .key(fileName)
                    .build();

            ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(getObjectRequest);
            byte[] fileBytes = objectBytes.asByteArray();

            // Set content type from S3 response
            String contentType = Optional.ofNullable(objectBytes.response().contentType())
                    .orElse(MediaType.APPLICATION_OCTET_STREAM_VALUE);

            Resource resource = new ByteArrayResource(fileBytes);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .contentType(MediaType.parseMediaType(contentType))
                    .body(resource);

        } catch (Exception e) {
            // Handle exceptions like file not found in S3
            return ResponseEntity.notFound().build();
        }
    }
}