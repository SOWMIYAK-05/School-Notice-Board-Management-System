// src/main/java/com/student/notice/management/system/service/ContentService.java
package com.student.notice.management.system.service;

import com.student.notice.management.system.model.Comment;
import com.student.notice.management.system.model.Content;
import com.student.notice.management.system.model.Notification;
import com.student.notice.management.system.model.User;
import com.student.notice.management.system.repository.CommentRepository;
import com.student.notice.management.system.repository.ContentRepository;
import com.student.notice.management.system.repository.NotificationRepository;
import com.student.notice.management.system.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ContentService {

    private final ContentRepository contentRepository;
    private final UserRepository userRepository;
    private final S3Client s3Client;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    private final NotificationRepository notificationRepository;
    private final CommentRepository commentRepository;

    private final String uploadDir = "uploads/";

    @Transactional
    public void deleteContent(Long contentId, String role) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        if (content.getAttachments() != null) {
            for (String path : content.getAttachments()) {
                try {
                    // Extract the file name from the URL to delete the file from the disk
                    String fileName = Paths.get(path).getFileName().toString();
                    Files.deleteIfExists(Paths.get(uploadDir, fileName));
                } catch (IOException e) {
                    throw new RuntimeException("Failed to delete file: " + path, e);
                }
            }
        }
        contentRepository.delete(content);
    }

    private List<String> saveFiles(List<MultipartFile> files) throws IOException {
        if (files == null || files.isEmpty()) {
            return List.of();
        }

        return files.stream().map(file -> {
            try {
                String originalFileName = file.getOriginalFilename();
                String uniqueName = UUID.randomUUID() + "-" + originalFileName;

                s3Client.putObject(
                        PutObjectRequest.builder()
                                .bucket(bucketName)
                                .key(uniqueName)
                                .contentType(file.getContentType())
                                .build(),
                        RequestBody.fromBytes(file.getBytes())
                );

                // Return public URL for file access
                return "https://" + bucketName + ".s3.amazonaws.com/" + uniqueName;

            } catch (IOException e) {
                throw new RuntimeException("Failed to upload file: " + file.getOriginalFilename(), e);
            }
        }).collect(Collectors.toList());
    }


    @Transactional
    public Content createOrUpdateContent(Content content, String role, boolean isDraft, List<MultipartFile> files) throws IOException {
        // Initialize lists if null
        if (content.getApprovalHistory() == null) content.setApprovalHistory(new ArrayList<>());
        if (content.getAttachments() == null) content.setAttachments(new ArrayList<>());
        if (content.getCategories() == null) content.setCategories(new ArrayList<>());
        if (content.getTags() == null) content.setTags(new ArrayList<>());
        if (content.getBookmarkedByUserIds() == null) content.setBookmarkedByUserIds(new ArrayList<>());

        // Handle draft or publish
        if (isDraft) {
            content.setStatus("DRAFT");
        } else {
            switch (role) {
                case "TEACHER":
                    content.setRequiresApproval(true);
                    content.setStatus("PENDING_APPROVAL");
                    content.setApprovalStage("DEPARTMENT_HEAD_REVIEW");
                    content.getApprovalHistory().add("Submitted by Teacher at " + LocalDateTime.now());
                    break;

                case "DEPARTMENT_HEAD":
                    content.setRequiresApproval(true);
                    content.setStatus("PENDING_APPROVAL");
                    content.setApprovalStage("ADMIN_REVIEW");
                    content.getApprovalHistory().add("Submitted by Department Head at " + LocalDateTime.now());
                    break;

                case "ADMIN":
                    content.setApproved(true);
                    content.setStatus("PUBLISHED");
                    content.setApprovalStage("NONE");
                    content.getApprovalHistory().add("Published directly by Admin at " + LocalDateTime.now());
                    sendNotifications(content);
                    break;

                default:
                    throw new RuntimeException("Unauthorized role.");
            }
        }

        // Upload files to AWS S3
        List<String> uploadedPaths = saveFiles(files);
        content.getAttachments().addAll(uploadedPaths);

        content.setUpdatedAt(LocalDateTime.now());

        return contentRepository.save(content);
    }

    @Transactional
    public Content publishContent(Long contentId, String role) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        if (content.getApprovalHistory() == null) content.setApprovalHistory(new ArrayList<>());

        if (!"DRAFT".equals(content.getStatus())) {
            throw new RuntimeException("Only draft content can be published.");
        }

        switch (role) {
            case "TEACHER" -> {
                content.setRequiresApproval(true);
                content.setStatus("PENDING_APPROVAL");
                content.setApprovalStage("DEPARTMENT_HEAD_REVIEW");
                content.getApprovalHistory().add("Submitted for approval by Teacher at " + LocalDateTime.now());
            }
            case "DEPARTMENT_HEAD" -> {
                content.setRequiresApproval(true);
                content.setStatus("PENDING_APPROVAL");
                content.setApprovalStage("ADMIN_REVIEW");
                content.getApprovalHistory().add("Submitted for approval by Department Head at " + LocalDateTime.now());
            }
            case "ADMIN" -> {
                content.setApproved(true);
                content.setStatus("PUBLISHED");
                content.setApprovalStage("NONE");
                content.getApprovalHistory().add("Published by Admin at " + LocalDateTime.now());
                sendNotifications(content);
            }
            default -> throw new RuntimeException("Unauthorized role.");
        }

        content.setUpdatedAt(LocalDateTime.now());
        return contentRepository.save(content);
    }

    public Content approveContent(Long contentId, String role) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        if (!"PENDING_APPROVAL".equals(content.getStatus())) {
            throw new RuntimeException("Content is not in a pending approval state.");
        }

        switch (role) {
            case "TEACHER" -> throw new RuntimeException("Teachers cannot approve content.");

            case "DEPARTMENT_HEAD" -> {
                if ("DEPARTMENT_HEAD_REVIEW".equals(content.getApprovalStage())) {
                    content.getApprovalHistory().add("Approved by Department Head at " + LocalDateTime.now());
                    content.setApprovalStage("ADMIN_REVIEW");
                } else {
                    throw new RuntimeException("Not at Department Head approval stage.");
                }
            }

            case "ADMIN" -> {
                if ("ADMIN_REVIEW".equals(content.getApprovalStage())
                        || "DEPARTMENT_HEAD_REVIEW".equals(content.getApprovalStage())) {
                    content.getApprovalHistory().add("Approved by Admin at " + LocalDateTime.now());
                    content.setApproved(true);
                    content.setStatus("PUBLISHED");
                    content.setApprovalStage("NONE");
                    sendNotifications(content);
                } else {
                    throw new RuntimeException("Not at Admin approval stage.");
                }
            }
            default -> throw new RuntimeException("Unauthorized role.");
        }
        return contentRepository.save(content);
    }

    public List<Content> searchContent(String keyword, String category, String tag, LocalDateTime start, LocalDateTime end, String status) {
        return contentRepository.advancedSearch(keyword, category, tag, start, end, status);
    }

    public Content bookmarkContent(Long contentId, Long userId) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));
        if (!content.getBookmarkedByUserIds().contains(userId)) {
            content.getBookmarkedByUserIds().add(userId);
            contentRepository.save(content);
        }
        return content;
    }

    public List<Content> getRelatedContent(Long contentId) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));
        return contentRepository.findAllById(content.getRelatedContentIds());
    }

    public void archiveExpiredContent() {
        LocalDateTime now = LocalDateTime.now();
        contentRepository.findAll().stream()
                .filter(c -> c.getScheduledEnd() != null && now.isAfter(c.getScheduledEnd()))
                .forEach(c -> {
                    c.setStatus("ARCHIVED");
                    c.setArchivedAt(now);
                    contentRepository.save(c);
                });
    }

    private void sendNotifications(Content content) {
        List<User> users;
        if (content.getSpecificUserIds() != null && !content.getSpecificUserIds().isEmpty()) {
            users = userRepository.findAllById(content.getSpecificUserIds());
        } else {
            users = userRepository.findAll();
        }

        String message = "📢 New notice published: " + content.getTitle();

        for (User user : users) {
            Notification notification = Notification.builder()
                    .contentId(content.getId())
                    .userId(user.getId())
                    .channel("IN_APP")
                    .delivered(true)
                    .deliveredAt(LocalDateTime.now())
                    .read(false)
                    .message(message)
                    .build();
            notificationRepository.save(notification);
        }
    }

    public List<Content> getVisibleContent(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        LocalDateTime now = LocalDateTime.now();

        return contentRepository.findAll().stream()
                .filter(c -> "PUBLISHED".equals(c.getStatus()))
                .filter(c -> (c.getScheduledStart() == null || !now.isBefore(c.getScheduledStart())))
                .filter(c -> (c.getScheduledEnd() == null || !now.isAfter(c.getScheduledEnd())))
                .filter(c -> c.getSpecificUserIds() == null || c.getSpecificUserIds().isEmpty() || c.getSpecificUserIds().contains(user.getId()))
                .filter(c -> c.getRoleVisibility() != null && c.getRoleVisibility().contains(user.getRole()))
                .toList();
    }

    public List<Content> getDraftContents(String role) {
        if (!Arrays.asList("ADMIN", "DEPARTMENT_HEAD", "TEACHER").contains(role)) {
            throw new RuntimeException("Unauthorized access to view draft content.");
        }
        return contentRepository.findAllByStatus("DRAFT");
    }

    public List<Content> getPublishedContents(String role) {
        if (!Arrays.asList("ADMIN", "DEPARTMENT_HEAD", "TEACHER", "STUDENT").contains(role)) {
            throw new RuntimeException("Unauthorized access to view published content.");
        }
        return contentRepository.findAllByStatus("PUBLISHED");
    }

    public Page<Content> getContentAnalytics(String status, int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc") ? Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return contentRepository.findAllByStatusWithPagination(status, pageable);
    }

    public Map<String, Object> calculateEngagementMetrics(Content content) {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("readCount", content.getReadCount());
        metrics.put("deliveryAttempts", content.getDeliveryAttempts());
        metrics.put("failedDeliveries", content.getFailedDeliveries());
        metrics.put("bookmarks", content.getBookmarkedByUserIds().size());
        metrics.put("viewScore", content.getViewScore());
        metrics.put("interactionScore", content.getInteractionScore());
        return metrics;
    }

    public List<Content> getPendingApprovalContents(String role, Long userId) {
        List<Content> pendingContents = contentRepository.findAllByStatus("PENDING_APPROVAL");

        if ("ADMIN".equals(role)) {
            return pendingContents.stream()
                    .peek(c -> c.getApprovalHistory()
                            .add("Currently waiting at stage: " + c.getApprovalStage()))
                    .toList();
        } else if ("DEPARTMENT_HEAD".equals(role)) {
            return pendingContents.stream()
                    .filter(c -> (c.getCreatedByUserId() != null && c.getCreatedByUserId().equals(userId)) ||
                            "TEACHER".equalsIgnoreCase(c.getCreatedByRole()))
                    .peek(c -> c.getApprovalHistory()
                            .add("Currently waiting at stage: " + c.getApprovalStage()))
                    .toList();
        } else if ("TEACHER".equals(role)) {
            return pendingContents.stream()
                    .filter(c -> c.getCreatedByUserId() != null && c.getCreatedByUserId().equals(userId))
                    .peek(c -> c.getApprovalHistory()
                            .add("Currently waiting at stage: " + c.getApprovalStage()))
                    .toList();
        } else {
            throw new RuntimeException("Unauthorized access to view pending approvals.");
        }
    }

    public Content viewPendingApprovalContent(Long contentId, String role) {
        if (!Arrays.asList("ADMIN", "DEPARTMENT_HEAD", "TEACHER").contains(role)) {
            throw new RuntimeException("Unauthorized access to view pending approval content.");
        }

        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        if (!"PENDING_APPROVAL".equals(content.getStatus())) {
            throw new RuntimeException("Content is not pending approval.");
        }

        if ("DEPARTMENT_HEAD".equals(role) && "TEACHER".equals(content.getCreatedByRole())) {
            return content;
        }
        if ("ADMIN".equals(role)) {
            return content;
        }

        throw new RuntimeException("You do not have permission to view this content.");
    }

    public Comment addComment(Long contentId, Long userId, String userName, String text) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        Comment comment = Comment.builder()
                .contentId(contentId)
                .userId(userId)
                .userName(userName)
                .text(text)
                .build();

        return commentRepository.save(comment);
    }

    public List<Comment> getComments(Long contentId) {
        return commentRepository.findByContentId(contentId);
    }

    public Content removeBookmark(Long contentId, Long userId) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        content.getBookmarkedByUserIds().remove(userId);
        return contentRepository.save(content);
    }

    public List<Notification> getNotifications(Long userId) {
        return notificationRepository.findByUserId(userId);
    }

    public Notification markNotificationAsRead(Long notificationId, Long userId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found"));

        if (!notification.getUserId().equals(userId)) {
            throw new RuntimeException("Not authorized to update this notification");
        }

        notification.setRead(true);
        notification.setReadAt(LocalDateTime.now());
        return notificationRepository.save(notification);
    }
    public void incrementViewScore(Long contentId) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        // Increase view count
        content.setViewScore(content.getViewScore() + 1);

        contentRepository.save(content);
    }
    public void updateInteractionScore(Long contentId, String action) {
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new RuntimeException("Content not found"));

        int score = content.getInteractionScore();

        switch (action.toLowerCase()) {
            case "comment":
                score += 5;
                break;
            case "bookmark":
                score += 3;
                break;
            case "remove_bookmark":
                score -= 3;
                break;
            // You can add "like", "share" later
            default:
                break;
        }

        content.setInteractionScore(score);
        contentRepository.save(content);
    }

}