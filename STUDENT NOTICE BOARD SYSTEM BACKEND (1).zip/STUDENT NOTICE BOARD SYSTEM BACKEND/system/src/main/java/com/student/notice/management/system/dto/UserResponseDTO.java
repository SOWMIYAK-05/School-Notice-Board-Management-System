package com.student.notice.management.system.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserResponseDTO {
    private Long id;
    private String fullName;
    private String institutionalId;
    private String email;
    private String role;
    private String department;
    private String gradeLevel;
    private String emergencyContact;
    private boolean adminApproved;
    private String assignedClass;
    private Long childId;
}
