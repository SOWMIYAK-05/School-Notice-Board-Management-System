// src/main/java/com/student/notice/management/system/dto/ContentRequest.java
package com.student.notice.management.system.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ContentRequest {
    private String title;
    private String body;
    private String roleVisibility;
    private String department;
    private String gradeLevel;
    private String classification;
    private String urgencyLevel;
    private boolean featured;
    private LocalDateTime scheduledStart;
    private LocalDateTime scheduledEnd;
    private String recurrence;
    private String categories; // Comma-separated string
    private String tags;       // Comma-separated string
}