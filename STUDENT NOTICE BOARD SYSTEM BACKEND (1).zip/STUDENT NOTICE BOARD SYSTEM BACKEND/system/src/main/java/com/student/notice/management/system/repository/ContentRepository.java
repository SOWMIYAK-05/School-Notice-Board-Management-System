package com.student.notice.management.system.repository;

import com.student.notice.management.system.model.Content;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface ContentRepository extends JpaRepository<Content, Long> {

    List<Content> findByRoleVisibilityContaining(String role);
    List<Content> findByDepartmentAndGradeLevel(String department, String gradeLevel);
    List<Content> findByStatus(String status);
    List<Content> findAllByStatus(String status);

    @Query("SELECT c FROM Content c WHERE " +
            "(:keyword IS NULL OR LOWER(c.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(c.body) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
            "(:category IS NULL OR :category MEMBER OF c.categories) AND " +
            "(:tag IS NULL OR :tag MEMBER OF c.tags) AND " +
            "(:startDate IS NULL OR c.scheduledStart >= :startDate) AND " +
            "(:endDate IS NULL OR c.scheduledEnd <= :endDate) AND " +
            "(:status IS NULL OR c.status = :status)")
    List<Content> advancedSearch(@Param("keyword") String keyword,
                                 @Param("category") String category,
                                 @Param("tag") String tag,
                                 @Param("startDate") LocalDateTime startDate,
                                 @Param("endDate") LocalDateTime endDate,
                                 @Param("status") String status);

    // ✅ Pagination & Sorting support
    @Query("SELECT c FROM Content c WHERE " +
            "(:status IS NULL OR c.status = :status)")
    Page<Content> findAllByStatusWithPagination(@Param("status") String status, Pageable pageable);
}
